import java.util.ArrayList;
import java.util.Scanner;

class Edge
{
    int v1;
    int v2;
    int weight;
    boolean picked;
    public Edge(int v1,int v2,int weight)
    {
        this.v1=v1;
        this.v2=v2;
        this.weight=weight;
        this.picked=false;
    }
}
class Graph
{
    int vertices;
    int edges;
    ArrayList<Edge> edge;
    public Graph(int vertices,int edges)
    {
        this.vertices=vertices;
        this.edges=edges;
        edge=new ArrayList<>();
    }
    public void addEdge(int v1,int v2,int wt)
    {
        Edge e=new Edge(v1,v2,wt);
        edge.add(e);
    }
    public void printEdges()
    {
        for(int i=0;i<edge.size();i++)
        {
            System.out.println(edge.get(i).v1+" "+edge.get(i).v2+" "+edge.get(i).weight);
            System.out.print("\n");
        }
    }
}
public class Main {
    public static void prim(Graph g,int vertices,int edges)
    {
        ArrayList<Edge> list=new ArrayList<>();
        ArrayList<Integer> lst=new ArrayList<>();
        Graph p=new Graph(vertices,edges);
        int v2=1,index=0,vertex1=0,vertex2=0;
        int minWt=Integer.MAX_VALUE;
        for(int i=0;i<vertices-1;i++)
        {
            for(int j=0;j<g.edge.size();j++)
            {
                if(v2==g.edge.get(j).v1)
                {
                    list.add(g.edge.get(j));
                }
            }
            minWt=Integer.MAX_VALUE;
            for(int k=0;k<list.size();k++)
            {
                if(list.get(k).weight<minWt)
                {
                    minWt=list.get(k).weight;
                    vertex1=list.get(k).v1;
                    vertex2=list.get(k).v2;
                    index=k;
                }
            }
            boolean check=false;
            list.remove(index);
            v2=vertex2;
            p.addEdge(vertex1, vertex2, minWt);
            lst.add(vertex1);
        }
        p.printEdges();
    }
    public static void main(String []args)
    {
        Scanner scanner=new Scanner(System.in);
        int vertex,edge;
        System.out.println("Enter no of vertices:");
        vertex=scanner.nextInt();
        System.out.println("Enter no of edges:");
        edge=scanner.nextInt();
        Graph g=new Graph(vertex,edge);
        int vertex1[]=new int[edge];
        int vertex2[]=new int[edge];
        int weight[]=new int[edge];
        for(int i=0;i<edge;i++)
        {
            System.out.println("Enter vertex 1:");
            vertex1[i]=scanner.nextInt();
            System.out.println("Enter vertex 2:");
            vertex2[i]=scanner.nextInt();
            if((vertex1[i]>vertex||vertex2[i]>vertex)||(vertex1[i]<1||vertex2[i]<1)||vertex2[i]<=vertex1[i])
            {
                System.out.println("Not possible.");
                System.exit(-1);
            }
            else
            {
                System.out.println("Enter weight:");
                weight[i] = scanner.nextInt();
            }
        }
        for(int i=0;i<edge;i++)
        {
            for(int j=0;j<edge-1;j++)
            {
                if(vertex1[j]>vertex1[j+1])
                {
                    int tmp=weight[j];
                    weight[j]=weight[j+1];
                    weight[j+1]=tmp;
                    tmp=vertex1[j];
                    vertex1[j]=vertex1[j+1];
                    vertex1[j+1]=tmp;
                    tmp=vertex2[j];
                    vertex2[j]=vertex2[j+1];
                    vertex2[j+1]=tmp;
                }
            }
        }
        for(int i=0;i<edge;i++)
        {
            g.edge.add(new Edge(vertex1[i],vertex2[i],weight[i]));
        }
        prim(g,vertex,edge);
    }
}
