import java.util.ArrayList;

/**
 * Created by kunal on 13-10-2017.
 */
public class nw {
    public static void main(String[] args)
    {
        ArrayList<Integer> a=new ArrayList<>();
        a.add(5);
        a.add(6);
        a.add(3);
        a.add(1);
        a.remove(2);
        System.out.println(a.get(2));
    }
}
